import "./about/swiper";
import "./home/swiper";
import "./event/galleryImage";
import "../css/about.scss";
