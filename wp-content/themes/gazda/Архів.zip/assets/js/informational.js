import "./shop/accordeon"

import "../css/informational.scss"