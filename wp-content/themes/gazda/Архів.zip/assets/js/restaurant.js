import "./restaurant/restaurantMenu"
import "./restaurant/wishlist"

import "../css/restaurant.scss"