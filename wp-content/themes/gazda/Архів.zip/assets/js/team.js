import "bootstrap/dist/css/bootstrap.css";
import "modern-normalize/modern-normalize.css";

import "./main/utils"
import "./event/select"
import "./event/inputMask"
import "./team/popup"
import "./event/formSubmit"

import "../css/team.scss"