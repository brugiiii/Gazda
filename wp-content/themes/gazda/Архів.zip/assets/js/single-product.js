import "./single-product/swiper"
import "./single-product/updateProductQuantity"
import "./single-product/updateProductVariation"
import "./single-product/addToCart"
import "./single-product/fiveStarRating"
import "./single-product/tabsCarousel"

import "../css/single-product.scss"