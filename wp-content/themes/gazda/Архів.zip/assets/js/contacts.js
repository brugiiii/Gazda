import "./event/inputMask"
import "./event/select"
import "./event/formSubmit"

import "../css/contacts.scss"