import "./shop/fetchProducts"
import "./shop/listsVisibility"
import "./shop/addToCard"
import "./shop/productQuantity"
import "./shop/readMore"
import "./shop/accordeon"
import "./shop/popup"

import "../css/shop.scss"