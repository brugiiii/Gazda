import "./event/inputMask"
import "./account/contentVisibility"
import "./account/formSubmit"
import "./account/inputType"
import "./account/swiper"
import "./account/getOrderInfo"

import "../css/account.scss"