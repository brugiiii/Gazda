import "./delivery/categoriesMenu"
import "./delivery/categoryButtonsHandlers"

import "../css/delivery.scss"