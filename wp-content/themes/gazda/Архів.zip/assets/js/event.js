import "./event/inputMask"
import "./event/select"
import "./event/swiper"
import "./event/formSubmit"


import "../css/event.scss"